<?php

class Usuario{
    public $id;
    public $correo;
    public $clave;
    public $nombre;
    public $apellido;
    public $perfil;

    public function __construct($id=null,$correo=null,$clave=null,$nombre=null,$apellido=null,$perfil=null){
        if ($id != null) {$this->id = $id;}
        if ($correo != null) {$this->correo = $correo;}
        if ($clave != null) {$this->clave = $clave;}
        if ($nombre != null) {$this->nombre = $nombre;}
        if ($apellido != null) {$this->apellido = $apellido;}
        if ($perfil != null) {$this->perfil = $perfil;}
    }

    public function Traer($id = null){
        //$retorno = array();
        if($id != null){
            if(BaseDatos::BasedatosConexion()!= null){
                
            $sql = "SELECT * FROM usuarios WHERE id={$id}";

            $recurso = mysql_db_query(BaseDatos::$base,$sql);

            if ($recurso !== false) {
                var_dump($recurso);
            }
            else {
                echo "null";
            }
            //var_dump($_POST);

            BaseDatos::CerrarConexion();
            }
            else {
                echo "no se pudo establecer conexion con la base";
            }

        }
    }

    public function TraerTodos(){
        //$retorno = null;

        if(BaseDatos::BasedatosConexion() != null){
            $sql = "SELECT * FROM usuarios";

            $recurso = mysql_db_query(BaseDatos::$base,$sql);
            if($recurso !== false){
                var_dump($recurso);
            }
            else {
                echo "null";
            }

            BaseDatos::CerrarConexion();
        }
        else {
            echo "no se pudo establecer conexion con la base";
        }


    }

    public function Eliminar(){
        $retorno = false;

        if(BaseDatos::BasedatosConexion() != null){
            $sql = "DELETE * FROM usuarios";

            $recurso = mysql_db_query(BaseDatos::$base,$sql);
            if($recurso !== false){
                $retorno = true;
            }
            else {
                echo "null";
            }

            BaseDatos::CerrarConexion();
        }
        else {
            echo "no se pudo establecer conexion con la base";
        }

        return $retorno;
    }

    public static function Agregar($obj){
        $retorno = false;
        if(BaseDatos::BasedatosConexion() != null){
            $sql = "INSERT INTO usuarios (id,correo,clave,nombre,apellido,perfil) 
                    VALUES (".$obj->id.",'".$obj->correo."','".$obj->clave."','".$obj->nombre."','".$obj->apellido."',".$obj->perfil")";

            $recurso = mysql_db_query(BaseDatos::$base,$sql);
            if($recurso !== false){
                $retorno = true;
            }
            else {
                echo "null";
            }

            BaseDatos::CerrarConexion();
        }
        else {
            echo "no se pudo establecer conexion con la base";
        }

        return $retorno;
    }

    public static function Modificar($obj){
        $retorno = false;
        if(BaseDatos::BasedatosConexion() != null){
            $sql = "UPDATE  usuarios SET correo = 'cambiado@hotmail.com', ";

            $recurso = mysql_db_query(BaseDatos::$base,$sql);
            if($recurso !== false){
                $retorno = true;
            }
            else {
                echo "null";
            }

            BaseDatos::CerrarConexion();
        }
        else {
            echo "no se pudo establecer conexion con la base";
        }

        return $retorno;
    }

}

class BaseDatos{
    public static $base="usuarios";//usuarios
    private $user="root";//root
    private $clave="";//""

    public static function BasedatosConexion(){
       return $conec = mysql_connect("localhost","root","");
    }

    public static function CerrarConexion(){
        mysql_close(BaseDatos::BasedatosConexion());
    }
}





